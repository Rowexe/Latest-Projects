Thank you for downloading from https://github.com/Rowexe


Credits:
	The whole python nim code is copied from the "python demo", I have done this so that people who don't/can't download python can have fun with it without having to download python!

What I have done:
		I have made some tweaks in the "python demo" code which will make it fit into this program, it does take time to load though because of this.

